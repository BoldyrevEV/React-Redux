import React from 'react'
import './HomePage.css'

export default class HomePage extends React.Component {
    render() {
        return (        
            <div className="home-page">
                <div className="home-page__img"></div>       
                <div className="main-content">
                    <p className="main-content__main-text">CATALOGONE</p>
                    <span className="main-content__span"></span>
                    <h3>The heart of your organization</h3>
                </div>
                <div className="section__img"></div>  
                <section className="section">                                               
                    <header className="header">CatalogONE is the heart of your business</header>
                    <article className="article">
                        <p className="article__text">- Advanced business models &amp; offerings – consumer &amp; business</p>
                        <p className="article__text">- Personalized and contextual offers, pricing &amp; promotions</p>
                        <p className="article__text">- Digital services, ICT services, virtualization</p>
                        <p className="article__text">- Consistency across systems &amp; touch points</p>
                        <p className="article__text">- Ability to understand and re-act to business changes in real-time</p>                   
                    </article>       
                </section>
            </div>
        );
    }
}