import React from 'react'
import { connect } from 'react-redux'
import './RealContent.css'

import Card from '../Components/Card'

class RealContent extends React.Component {
    render() {      
        const cards = this.props.state.map((elem) => {
            return <Card 
                        key={ elem.id } 
                        id={ elem.id }
                        name={ elem.name }
                        email={ elem.email }
                        city={ elem.address.city }
                        phone={ elem.phone }
                        website={ elem.website }
                        companyName={ elem.company.name }
                    />
        });

        return (
            <div className="cards">
                <div className="cards__img"></div> 
                { cards }
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        state: state
    };
}

export default connect(mapStateToProps)(RealContent);