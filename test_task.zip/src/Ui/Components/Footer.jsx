import React from 'react'
import './Footer.css'

export default class Footer extends React.Component {
    render() {
        return (
            <footer className='footer'>
                <div className="footer-content">
                   <div className="footer-content__icon"></div>
                <p>© 2019 Company, Inc.</p>
                </div>                 
            </footer>
        )
    }
}