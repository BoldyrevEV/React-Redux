import React from 'react'
import './ModalInput.css'

export default class ModalInput extends React.Component {
    render() {
        return (
            <p className="modalwindow__content">
                <label className="modalwindow__content__label">{ this.props.name }</label>
                <input type="text" 
                    defaultValue={ this.props.value } 
                    onInput={ this.props.onInput } 
                    style={{borderColor:this.props.style}} 
                    className="modalwindow__content__input"
                    maxlength='30'
                /> 
            </p>
        )
    }
}