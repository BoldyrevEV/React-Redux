import React from 'react'
import ModalWindow from './ModalWindow'
import './Card.css'

export default class Card extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            showModal: false,
        }       
    }

    modalWindow = () => {
        this.setState({
            showModal: !this.state.showModal,
        })        
    }

    render() {
        return (
            <React.Fragment>
                { this.state.showModal ? 
                    <ModalWindow 
                        showModal={this.modalWindow} 
                        id={ this.props.id }
                        name={ this.props.name }
                        email={ this.props.email }
                        city={ this.props.city }
                        phone={ this.props.phone }
                        website={ this.props.website }
                        companyName={ this.props.companyName }
                    /> : null
                }  

                <section className="cards__section" onDoubleClick={ () => this.modalWindow() }>
                    <header className="cards__section__header">{ this.props.name }</header>
                    <article className="cards__section__article">
                        <p>{ this.props.email }</p>
                        <p>{ this.props.city }</p>
                        <p>{ this.props.phone }</p>
                        <p>{ this.props.website }</p>
                        <p>{ this.props.companyName }</p>
                    </article>
                </section> 
            </React.Fragment>                
        )        
    }
}