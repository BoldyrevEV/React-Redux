import React from 'react'
import { connect } from 'react-redux'
import ModalInput from './ModalInput'
import onEdit from '../../store/Actions/actionTypes'
import './ModalWindow.css'

class ModalWindow extends React.Component {
    constructor(props) {
        super(props);
 
        this.objectInput = {
            id: this.props.id,
            name: this.props.name,
            email: this.props.email,
            city: this.props.city,
            phone: this.props.phone,
            website: this.props.website,
            companyName: this.props.companyName,
        }

        this.state = {
            nameValid: this.validateString(this.props.name),
            emailValid: this.validateEmail(this.props.email),
            cityValid: this.validateString(this.props.city),
            phoneValid: this.validatePhone(this.props.phone),
            websiteValid: this.validateWebsite(this.props.website),
            companyNameValid: this.validateCompanyName(this.props.companyName),   
        };
    }

    validateString = string => string.length > 2 && string.search(/\d/) === -1;
    validateEmail = string => string.length > 2 && string.indexOf('@') !== -1;
    validateWebsite = string => string.length > 4 && string.indexOf('.') !== -1;
    validateCompanyName = string => string.length > 2;
    validatePhone = string => {
        const newString = string.replace(/\(/g, '')
                                .replace(/\)/g, '')
                                .replace(/-/g, '')
                                .replace(/\+/g, '')
                                .replace(/x/g, '')
                                .replace(/\./g, '')
                                .replace(/ /g, '');

        return string.length > 9 && newString.search(/^[0-9]+$/) !== -1;
    }

    onNameChange = event => {
        this.objectInput.name = event.target.value;
        this.setState({nameValid: this.validateString(event.target.value)});
    }

    onEmailChange = event => {
        this.objectInput.email = event.target.value;
        this.setState({emailValid: this.validateEmail(event.target.value)});
    }

    onCityChange = event => {
        this.objectInput.city = event.target.value;
        this.setState({cityValid: this.validateString(event.target.value)});
    }

    onPhoneChange = event => {
        this.objectInput.phone = event.target.value;
        this.setState({phoneValid: this.validatePhone(event.target.value)});
    }

    onWebsiteChange = event => {
        this.objectInput.website = event.target.value;
        this.setState({websiteValid: this.validateWebsite(event.target.value)});
    }

    onCompanyNameChange = event => {
        this.objectInput.companyName = event.target.value;
        this.setState({companyNameValid: this.validateCompanyName(event.target.value)});
    }

    globalClose = event => {
        if(event.target.classList.value === 'modalbackground') {
            return this.props.showModal();
        }
    }

    saveChange = () => {
        const state = this.state;
               
        if (state.nameValid && 
            state.emailValid && 
            state.cityValid && 
            state.phoneValid && 
            state.websiteValid && 
            state.companyNameValid) {
           return (this.props.onEdit(this.objectInput), this.props.showModal()); 
        }        
    }

    render() {
        let nameColor = this.state.nameValid ? "#52ff00" : "red";
        let emailColor = this.state.emailValid ? "#52ff00" : "red";
        let cityColor = this.state.cityValid ? "#52ff00" : "red";
        let phoneColor = this.state.phoneValid ? "#52ff00" : "red";
        let websiteColor = this.state.websiteValid ? "#52ff00" : "red";
        let companyColor = this.state.companyNameValid ? "#52ff00" : "red";

        return (                    
            <div className="modalbackground" onClick={ event=>this.globalClose(event) }>
                <section className="modalwindow">
                    <header className="modalwindow__header">Editing card</header>

                    <ModalInput value={ this.objectInput.name } 
                                onInput={ this.onNameChange } 
                                style={ nameColor } 
                                name="Name:"
                    />
                    <ModalInput value={ this.objectInput.email } 
                                onInput={ this.onEmailChange } 
                                style={ emailColor } 
                                name="Email:"
                    />
                    <ModalInput value={ this.objectInput.city } 
                                onInput={ this.onCityChange } 
                                style={ cityColor } 
                                name="City:"
                    />
                    <ModalInput value={ this.objectInput.phone } 
                                onInput={ this.onPhoneChange } 
                                style={ phoneColor } 
                                name="Phone:"
                    />
                    <ModalInput value={ this.objectInput.website } 
                                onInput={ this.onWebsiteChange } 
                                style={ websiteColor } 
                                name="Website:"
                    />
                    <ModalInput value={ this.objectInput.companyName } 
                                onInput={ this.onCompanyNameChange } 
                                style={ companyColor } 
                                name="Company name:"
                    />
      
                    <div className="modalwindow__btn-block">
                        <button className="modalwindow__btn" onClick={ () => this.saveChange() }>Save</button>
                        <button className="modalwindow__btn" onClick={ this.props.showModal }>Cancel</button>
                    </div>
 
                </section>
            </div>                     
        )        
    }
}

function mapDispatchToProps(dispatch) {
    return {
        onEdit: object => dispatch(onEdit(object))
    };
}

export default connect(null, mapDispatchToProps)(ModalWindow);