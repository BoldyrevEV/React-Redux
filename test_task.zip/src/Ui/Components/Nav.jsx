import React from 'react'
import { NavLink } from 'react-router-dom'
import './Nav.css'

export default class Nav extends React.Component { 
    render() {
        return (
            <nav>
                <div className="nav-link__content">
                    <NavLink className="link" to="/">Home page</NavLink>
                    <NavLink className="link" to="/content">Real content</NavLink>
                </div>
            </nav>                
        )        
    }
}