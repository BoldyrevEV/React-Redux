import data from './assignment.json';

const initialState = data;

function search(initialState, object) {
    let newState = initialState.map(element => {      
        if (element.id === object.id) {
            element.name = object.name;
            element.email = object.email;
            element.address.city = object.city;
            element.phone = object.phone;
            element.website = object.website;
            element.company.name = object.companyName;
            return element;    
        }
        return element; 
    });
    return newState;
}

export default function rootReduсer(state=initialState, action) {
    switch (action.type) {
        case 'EDIT':
            return search(initialState, action.payload);
        default:
            return state;
    }  
}