export default function onEdit(object) {
    return {
        type: 'EDIT', 
        payload: object,
    }
}
