import React from 'react';
import { Route } from 'react-router-dom'
import HomePage from './Ui/Pages/HomePage'
import RealContent from './Ui/Pages/RealContent'
import Nav from './Ui/Components/Nav'
import Footer from './Ui/Components/Footer'
import './App.css';

export default class App extends React.Component {
    render() {
        return (
            <React.Fragment>                
                <Nav />
                <Route path="/" exact component={ HomePage }/>
                <Route path="/content" component={ RealContent }/>
                <Footer />
            </React.Fragment>
        ); 
    }
}